import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { supabase, configReady } from './supabase';
import './style.css';

function App(){
 const [session,setSession]=useState(null),[profile,setProfile]=useState(null),[mode,setMode]=useState('login');
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[name,setName]=useState(''),[role,setRole]=useState('customer');
 const [products,setProducts]=useState([]),[message,setMessage]=useState(''),[loading,setLoading]=useState(false);
 useEffect(()=>{ if(!configReady)return; supabase.auth.getSession().then(({data})=>setSession(data.session)); const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s)); return ()=>subscription.unsubscribe(); },[]);
 useEffect(()=>{ if(session) loadProfile(); else {setProfile(null);setProducts([]);} },[session]);
 async function loadProfile(){
  const {data,error}=await supabase.from('profiles').select('id,full_name,role,phone,address').eq('id',session.user.id).maybeSingle();
  if(error) setMessage('প্রোফাইল লোড হয়নি: '+error.message); else setProfile(data);
  const p=await supabase.from('products').select('id,name,description,price,stock,image_urls,active').eq('active',true).order('created_at',{ascending:false}).limit(30);
  if(!p.error) setProducts(p.data||[]);
 }
 async function submit(e){e.preventDefault();setLoading(true);setMessage('');
  try{
   if(mode==='register'){
    const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name,role}}});
    if(error) throw error;
    setMessage(data.session?'অ্যাকাউন্ট তৈরি হয়েছে।':'অ্যাকাউন্টের অনুরোধ হয়েছে। ইমেইল কনফার্মেশন চালু থাকলে ইনবক্স দেখে নিশ্চিত করুন।');
   } else {const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;setMessage('লগইন সফল।');}
  }catch(err){setMessage(err.message||'কাজটি সম্পন্ন হয়নি।');}finally{setLoading(false);}
 }
 async function applySeller(){const {error}=await supabase.from('seller_profiles').upsert({id:session.user.id,shop_name:(profile?.full_name||'আমার দোকান')+' Shop',approved:false},{onConflict:'id'});setMessage(error?'Seller আবেদন হয়নি: '+error.message:'Seller আবেদন জমা হয়েছে। Admin অনুমোদনের অপেক্ষা করুন।');}
 async function signout(){await supabase.auth.signOut();setMessage('লগআউট হয়েছে।');}
 if(!configReady)return <main className="wrap"><Header/><section className="panel"><h2>Supabase Configuration পাওয়া যায়নি</h2><p>Netlify Environment Variables-এ নিচের দুটি নাম হুবহু থাকতে হবে:</p><code>VITE_SUPABASE_URL</code><code>VITE_SUPABASE_ANON_KEY</code><p>দুটি Variable যোগ/সংশোধনের পর নতুন Deploy করতে হবে। Value হিসেবে Supabase Project URL এবং Publishable/Anon key দিন। কখনো service_role key দেবেন না।</p></section></main>;
 return <main className="wrap"><Header/>{!session?<section className="panel auth"><h2>{mode==='login'?'লগইন':'নতুন অ্যাকাউন্ট'}</h2><div className="tabs"><button className={mode==='login'?'selected':''} onClick={()=>setMode('login')}>লগইন</button><button className={mode==='register'?'selected':''} onClick={()=>setMode('register')}>রেজিস্টার</button></div><form onSubmit={submit}>{mode==='register'&&<><label>আপনার নাম</label><input required value={name} onChange={e=>setName(e.target.value)} placeholder="পূর্ণ নাম"/><label>অ্যাকাউন্টের ধরন</label><select value={role} onChange={e=>setRole(e.target.value)}><option value="customer">Customer</option><option value="seller">Seller</option></select></>}<label>ইমেইল</label><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com"/><label>পাসওয়ার্ড</label><input required minLength="6" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="কমপক্ষে ৬ অক্ষর"/><button className="primary" disabled={loading}>{loading?'অপেক্ষা করুন…':mode==='login'?'লগইন করুন':'অ্যাকাউন্ট তৈরি করুন'}</button></form></section>:<><section className="panel"><div className="topline"><div><h2>স্বাগতম, {profile?.full_name||session.user.email}</h2><p>অ্যাকাউন্ট: {profile?.role||'প্রোফাইল সেটআপ অপেক্ষমাণ'}</p></div><button onClick={signout}>লগআউট</button></div>{profile?.role==='seller'&&<p>Seller Dashboard: আপনার পণ্য যুক্ত করতে Admin approval প্রয়োজন।</p>}{profile?.role==='admin'&&<p>Admin Dashboard: পণ্য, অর্ডার ও Seller অনুমোদন ব্যবস্থাপনা এখানে সংযুক্ত করতে হবে।</p>}{profile?.role==='customer'&&<p>Customer Account সক্রিয়। নিচে পণ্য দেখুন।</p>}{profile?.role!=='seller'&&profile?.role!=='admin'&&<button onClick={applySeller}>Seller হওয়ার আবেদন করুন</button>}</section><section><h2>সাম্প্রতিক পণ্য</h2><div className="products">{products.length?products.map(p=><article className="product" key={p.id}>{p.image_urls?.[0]&&<img src={p.image_urls[0]} alt={p.name}/>}<h3>{p.name}</h3><p>{p.description}</p><b>৳ {p.price}</b><small>স্টক: {p.stock}</small></article>):<div className="panel">এখনো কোনো পণ্য প্রকাশ করা হয়নি।</div>}</div></section></>}{message&&<p className="notice">{message}</p>}<footer>© {new Date().getFullYear()} Shayan Shop Zone · MD. ROBIUL ISLAM</footer></main>
}
function Header(){return <header className="header"><div className="logo">SSZ</div><div><h1>Shayan Shop Zone</h1><p>বিশ্বাসের সাথে অনলাইন শপিং</p></div></header>}

createRoot(document.getElementById('root')).render(<App/>);
