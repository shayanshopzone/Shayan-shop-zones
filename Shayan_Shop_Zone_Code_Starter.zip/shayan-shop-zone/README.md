# Shayan Shop Zone — Starter Website

Blue/white React + Vite + Supabase starter with email/password sign-in, customer/seller registration, product listing, and seller application UI.

## Important
This is a clean starter project, not a verified replacement for the existing live site's full backend. It relies on your existing Supabase schema and Row Level Security. Admin privileges must be assigned securely in Supabase by a trusted project owner; never allow public admin signup.

## Environment variables
Create `.env` from `.env.example` and set:
- `VITE_SUPABASE_URL` = Supabase project URL
- `VITE_SUPABASE_ANON_KEY` = Supabase publishable/anon key

Never put a `service_role` key in browser code.

## Run/build
```bash
npm install
npm run dev
npm run build
```
The production output is `dist/`.

## Netlify
Build command: `npm run build`
Publish directory: `dist`
Set the two environment variables in Netlify, then trigger a new deploy. If using manual deploy, upload the contents of `dist`, not this source ZIP.

## Supabase notes
The app expects `profiles` with `id`, `full_name`, `role`, `phone`, `address`; `products` with `id`, `name`, `description`, `price`, `stock`, `image_urls`, `active`, `created_at`; and `seller_profiles` with `id`, `shop_name`, `approved`. Keep RLS enabled. Existing policies/triggers must create the profile row at signup and prevent users from setting their own role to admin or approving themselves.
